import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.*;

import org.apache.commons.io.FileUtils;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.InvalidRemoteException;
import org.eclipse.jgit.api.errors.TransportException;
import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevObject;
import org.eclipse.jgit.revwalk.RevWalk;

public class CovidGraphSpread {

	public static void main(String[] args)
			throws InvalidRemoteException, TransportException, GitAPIException, IOException {
		Git git = Git.cloneRepository() .setURI("https://github.com/vbasto-iscte/ESII1920.git")
		  .setDirectory(new File("rep_covid")) .call();
		 
		/*
		 * FileRepositoryBuilder repositoryBuilder = new FileRepositoryBuilder();
		 * Repository repository = repositoryBuilder.setGitDir(new
		 * File("rep_covid/.git")) .readEnvironment() // scan environment GIT_*
		 * variables .findGitDir() // scan up the file system tree .setMustExist(true)
		 * .build();*/
		 
		List<FileInfo> fileinfos = new ArrayList<>();

		//Git git = Git.open(new File("rep_covid/.git"));
		Repository repository = git.getRepository();

//		Collection<Ref> allTags = git.getRepository().getRefDatabase().getRefs( "refs/tags/" ).values();
		RevWalk revWalk = new RevWalk(git.getRepository());
		revWalk.markStart(revWalk.parseCommit(git.getRepository().resolve("HEAD")));

		List<Ref> list = git.tagList().call();
		Collection<ObjectId> commits = new LinkedList<ObjectId>();
		for (Ref tag : list) {

			String tagName = tag.getName().split("/")[2];
			RevObject object = revWalk.parseAny(tag.getObjectId());
			if (object instanceof RevCommit) {
				RevCommit commit = (RevCommit) object;
				String tagDescription = commit.getShortMessage();
				int fileTimestamp = commit.getCommitTime();
				fileinfos.add(new FileInfo(fileTimestamp, "covid19spreading.rdf", tagName, tagDescription));

			} else {
				// invalid
			}
			// ObjectId object = tag.getPeeledObjectId();
			// System.out.println(object);
		}
		String tabela = "<table style=\"width:100%\">\n" + "  <tr>\n" + "    <th>File Timestamp</th>\n"
				+ "    <th>File Name</th> \n" + "    <th>File tag</th>\n" + "	<th>Tag Description</th> \n"
				+ "    <th>Spread Visualization Link</th>\n" + "  </tr>";
		for (FileInfo f : fileinfos) {
			String row = "<tr>";
			row += "<td>" + f.getFileTimestamp() + "</td>";
			row += "<td>" + f.getFileName() + "</td>";
			row += "<td>" + f.getFileTag() + "</td>";
			row += "<td>" + f.getTagDescription() + "</td>";
			row += "<td> <a href=" + f.getSpreadVisualizationLink() + "> Visualizar dados </a> </td>";
			row += "</tr>";
			tabela += row;
		}
		tabela += "</table>";
		File f = new File("tabela.html");
		BufferedWriter bw = new BufferedWriter(new FileWriter(f));
		bw.write(tabela);
		bw.close();
		/*
		 * while (next != null) { // ::pseudo code:: // in real, iterate over allTags
		 * and compare each tag.getObjectId() with next
		 * //System.out.println(next.getShortMessage()); RevTree tree = next.getTree();
		 * //System.out.println("Having tree: " + tree);
		 * 
		 * // now try to find a specific file try (TreeWalk treeWalk = new
		 * TreeWalk(repository)) { treeWalk.addTree(tree); treeWalk.setRecursive(true);
		 * treeWalk.setFilter(PathFilter.create("covid_spread_graph.rdf")); if
		 * (!treeWalk.next()) { throw new
		 * IllegalStateException("Did not find expected file 'covid_spread_graph.rdf'");
		 * }
		 * 
		 * ObjectId objectId = treeWalk.getObjectId(0); ObjectLoader loader =
		 * repository.open(objectId);
		 * 
		 * } next = revWalk.next(); } revWalk.close();
		 */
		System.out.println(cgi_lib.Header());

		System.out.println(tabela);

		System.out.println(cgi_lib.HtmlBot());
		
		FileUtils.deleteDirectory(new File("rep_covid"));
	}
}
