
public class FileInfo {
	private int FileTimestamp; 
	private String FileName;
	private String FileTag; 
	private String TagDescription;
	private String SpreadVisualizationLink;
	
	// https://raw.githubusercontent.com/vbasto-iscte/ESII1920/NovoSurto/covid19spreading.rdf
	public FileInfo(int fileTimestamp, String fileName, String fileTag, String tagDescription) {
		super();
		FileTimestamp = fileTimestamp;
		FileName = fileName;
		FileTag = fileTag;
		TagDescription = tagDescription;
		SpreadVisualizationLink = "http://visualdataweb.de/webvowl/#iri=https://raw.githubusercontent.com/vbasto-iscte/ESII1920/" + fileTag + "/" + fileName;
	}

	public int getFileTimestamp() {
		return FileTimestamp;
	}

	public String getFileName() {
		return FileName;
	}

	public String getFileTag() {
		return FileTag;
	}

	public String getTagDescription() {
		return TagDescription;
	}

	public String getSpreadVisualizationLink() {
		return SpreadVisualizationLink;
	}
	
	
	
}
