package covid;

import java.awt.Desktop;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URL;
import java.security.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.InvalidRemoteException;
import org.eclipse.jgit.api.errors.TransportException;
import org.eclipse.jgit.errors.MissingObjectException;
import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.lib.ObjectLoader;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevTree;
import org.eclipse.jgit.revwalk.RevWalk;
import org.eclipse.jgit.treewalk.TreeWalk;
import org.eclipse.jgit.treewalk.filter.PathFilter;


public class compare {

	private Git git;
	private File file;
	private List<Ficheiro> ficheiros = new ArrayList<>(); 
	private List<ObjectLoader> ol = new ArrayList<ObjectLoader>();

	public void run() throws InvalidRemoteException, TransportException, GitAPIException, IOException {
		file = new File("Dad"); 
	
		if(file.isDirectory() && !file.exists()) {
			git = Git.cloneRepository().setURI("https://github.com/vbasto-iscte/ESII1920.git").setDirectory(file).call();
		} else {
			git = Git.open(file);
			git.pull();
			git.checkout();
		}
		
		Repository repository = git.getRepository();
		
		List<Ref> listTags = git.tagList().call(); 
		for (Ref ref : listTags) { 

			System.out.println("Tag: " + ref.getName());
			ObjectId tagFile = repository.resolve(ref.getName());

			try (RevWalk revWalk = new RevWalk(repository)) {

				RevCommit commit = revWalk.parseCommit(tagFile);
				RevTree tree = commit.getTree();

				try (TreeWalk treeWalk = new TreeWalk(repository)) {
					treeWalk.addTree(tree);
					treeWalk.setRecursive(true);
					treeWalk.setFilter(PathFilter.create("covid19spreading.rdf"));

					if (!treeWalk.next()) {
						throw new IllegalStateException("Did not find expected file 'covid19spreading.rdf'");
					}

					ObjectId o = treeWalk.getObjectId(0);
					ObjectLoader loader = repository.open(o);

					ficheiros.add(new Ficheiro(commit.getAuthorIdent().getWhen(), loader));
					ol.add(loader);	
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		
		PrintStream html = new PrintStream(new FileOutputStream("C:\\Users\\Ricardo\\eclipsePCD\\covid\\Dad\\fileHTML.html"));
		html.println(ficheiros);
		html.println("<br>");
		html.println("------------------------------ÚLTIMO FICHEIRO--------------------- <br>");
		html.println("------------------Alentejo------------------------------Algarve--------<br>");
		html.println("-Internamentos Infecoes Testes---Internamentos Infecoes Testes-<br>");
		ol.get(ol.size()-1).copyTo(html);
		html.println("<br>");
		html.println("<br>");
		html.println("----------------------------PENÚLTIMO FICHEIRO------------------ <br>");
		html.println("------------------Alentejo------------------------------Algarve--------<br>");
		html.println("-Internamentos Infecoes Testes---Internamentos Infecoes Testes-<br>");
		ol.get(ol.size()-2).copyTo(html);
		
		Desktop.getDesktop().browse(new File ("C:\\Users\\Ricardo\\eclipsePCD\\covid\\Dad\\fileHTML.html").toURI());
		
		System.out.println("Tamanho de ficheiros: ");
		System.out.println(ficheiros.size());

		
		getDados(ficheiros);
		
	}

	public List<Ficheiro> getDados(List<Ficheiro> ficheiros) throws MissingObjectException, IOException {
		List<Ficheiro> lista = new ArrayList<>();
		Ficheiro file1 = ficheiros.get(0);
		Integer index = 0;

		for (Ficheiro c : ficheiros) {
			if (c.getTm().after(file1.getTm())) 
				file1 = c;
				index = ficheiros.indexOf(c);
		}

		ficheiros.remove(ficheiros.get(index));
		Ficheiro file2 = ficheiros.get(1);

		for (Ficheiro c : ficheiros) {
			if (c.getTm().after(file2.getTm())) 
				file2 = c;
		}
		lista.add(file1);
		lista.add(file2);
		lista.get(0).getOl().copyTo(System.out);
		lista.get(1).getOl().copyTo(System.out);
		return lista;
	}

	public static void main(String[] args) {
		compare x = new compare();
		try {
			x.run();
		} catch (GitAPIException | IOException e) {
		
		}
	}
}

